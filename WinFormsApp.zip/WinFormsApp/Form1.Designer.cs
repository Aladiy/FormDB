﻿
namespace WinFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label13 = new System.Windows.Forms.Label();
            this.button_Autopark = new System.Windows.Forms.Button();
            this.textBox_phone = new System.Windows.Forms.TextBox();
            this.textBox_address = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.textBox_id = new System.Windows.Forms.TextBox();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.panel6 = new System.Windows.Forms.Panel();
            this.button1_change = new System.Windows.Forms.Button();
            this.label39 = new System.Windows.Forms.Label();
            this.button1_save = new System.Windows.Forms.Button();
            this.button1_delete = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox_searchAutopark = new System.Windows.Forms.TextBox();
            this.button6 = new System.Windows.Forms.Button();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.panel7 = new System.Windows.Forms.Panel();
            this.button2_change = new System.Windows.Forms.Button();
            this.label40 = new System.Windows.Forms.Label();
            this.button2_save = new System.Windows.Forms.Button();
            this.button2_delete = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label14 = new System.Windows.Forms.Label();
            this.textBox_searchCar = new System.Windows.Forms.TextBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.textBox_autoparkid = new System.Windows.Forms.TextBox();
            this.label44 = new System.Windows.Forms.Label();
            this.button_Car = new System.Windows.Forms.Button();
            this.label21 = new System.Windows.Forms.Label();
            this.textBox_incost = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.textBox_class = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.textBox_year = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.textBox_rental = new System.Windows.Forms.TextBox();
            this.textBox_status = new System.Windows.Forms.TextBox();
            this.textBox_mileage = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.textBox_color = new System.Windows.Forms.TextBox();
            this.textBox_model = new System.Windows.Forms.TextBox();
            this.textBox_statenum = new System.Windows.Forms.TextBox();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.panel8 = new System.Windows.Forms.Panel();
            this.button3_change = new System.Windows.Forms.Button();
            this.label41 = new System.Windows.Forms.Label();
            this.button3_save = new System.Windows.Forms.Button();
            this.button3_delete = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.label15 = new System.Windows.Forms.Label();
            this.textBox_searchClient = new System.Windows.Forms.TextBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.button_Client = new System.Windows.Forms.Button();
            this.label25 = new System.Windows.Forms.Label();
            this.textBox_numcar = new System.Windows.Forms.TextBox();
            this.label26 = new System.Windows.Forms.Label();
            this.textBox_patclient = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.textBox_phoneclient = new System.Windows.Forms.TextBox();
            this.textBox_addressclient = new System.Windows.Forms.TextBox();
            this.textBox_passport = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.textBox_surclient = new System.Windows.Forms.TextBox();
            this.textBox_nameclient = new System.Windows.Forms.TextBox();
            this.textBox_idclient = new System.Windows.Forms.TextBox();
            this.dataGridView3 = new System.Windows.Forms.DataGridView();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.panel9 = new System.Windows.Forms.Panel();
            this.button4_change = new System.Windows.Forms.Button();
            this.label42 = new System.Windows.Forms.Label();
            this.button4_save = new System.Windows.Forms.Button();
            this.button4_delete = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.label30 = new System.Windows.Forms.Label();
            this.textBox_searchRental = new System.Windows.Forms.TextBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.button_Rental = new System.Windows.Forms.Button();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.textBox_workerid = new System.Windows.Forms.TextBox();
            this.textBox_carid = new System.Windows.Forms.TextBox();
            this.textBox_clientid = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.textBox_days = new System.Windows.Forms.TextBox();
            this.textBox_date = new System.Windows.Forms.TextBox();
            this.textBox_request = new System.Windows.Forms.TextBox();
            this.dataGridView4 = new System.Windows.Forms.DataGridView();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.panel10 = new System.Windows.Forms.Panel();
            this.button5_change = new System.Windows.Forms.Button();
            this.label43 = new System.Windows.Forms.Label();
            this.button5_save = new System.Windows.Forms.Button();
            this.button5_delete = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.label38 = new System.Windows.Forms.Label();
            this.textBox_searchWorker = new System.Windows.Forms.TextBox();
            this.panel5 = new System.Windows.Forms.Panel();
            this.button_Worker = new System.Windows.Forms.Button();
            this.label31 = new System.Windows.Forms.Label();
            this.textBox_patworker = new System.Windows.Forms.TextBox();
            this.label32 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.textBox_opermode = new System.Windows.Forms.TextBox();
            this.textBox_phoneworker = new System.Windows.Forms.TextBox();
            this.textBox_position = new System.Windows.Forms.TextBox();
            this.label35 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.textBox_surworker = new System.Windows.Forms.TextBox();
            this.textBox_nameworker = new System.Windows.Forms.TextBox();
            this.textBox_idworker = new System.Windows.Forms.TextBox();
            this.dataGridView5 = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.panel1.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.panel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.tabPage2.SuspendLayout();
            this.panel7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.tabPage3.SuspendLayout();
            this.panel8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).BeginInit();
            this.tabPage4.SuspendLayout();
            this.panel9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).BeginInit();
            this.tabPage5.SuspendLayout();
            this.panel10.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            this.panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView5)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(6, 2);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 29;
            this.dataGridView1.Size = new System.Drawing.Size(631, 259);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellClick);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel1.Controls.Add(this.label13);
            this.panel1.Controls.Add(this.button_Autopark);
            this.panel1.Controls.Add(this.textBox_phone);
            this.panel1.Controls.Add(this.textBox_address);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.textBox_id);
            this.panel1.Location = new System.Drawing.Point(43, 286);
            this.panel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(419, 204);
            this.panel1.TabIndex = 2;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.ForeColor = System.Drawing.Color.Red;
            this.label13.Location = new System.Drawing.Point(52, 27);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(24, 20);
            this.label13.TabIndex = 8;
            this.label13.Text = "ID";
            // 
            // button_Autopark
            // 
            this.button_Autopark.Location = new System.Drawing.Point(214, 158);
            this.button_Autopark.Name = "button_Autopark";
            this.button_Autopark.Size = new System.Drawing.Size(118, 29);
            this.button_Autopark.TabIndex = 6;
            this.button_Autopark.Text = "Заполнить";
            this.button_Autopark.UseVisualStyleBackColor = true;
            this.button_Autopark.Click += new System.EventHandler(this.button_Autopark_Click);
            // 
            // textBox_phone
            // 
            this.textBox_phone.Location = new System.Drawing.Point(170, 107);
            this.textBox_phone.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox_phone.Name = "textBox_phone";
            this.textBox_phone.Size = new System.Drawing.Size(228, 27);
            this.textBox_phone.TabIndex = 2;
            // 
            // textBox_address
            // 
            this.textBox_address.Location = new System.Drawing.Point(170, 65);
            this.textBox_address.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox_address.Name = "textBox_address";
            this.textBox_address.Size = new System.Drawing.Size(228, 27);
            this.textBox_address.TabIndex = 1;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(52, 110);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(69, 20);
            this.label4.TabIndex = 5;
            this.label4.Text = "Телефон";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(23, 65);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(127, 20);
            this.label3.TabIndex = 4;
            this.label3.Text = "Адрес автопарка";
            // 
            // textBox_id
            // 
            this.textBox_id.Location = new System.Drawing.Point(170, 20);
            this.textBox_id.Name = "textBox_id";
            this.textBox_id.Size = new System.Drawing.Size(228, 27);
            this.textBox_id.TabIndex = 7;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Location = new System.Drawing.Point(12, 12);
            this.tabControl1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1230, 602);
            this.tabControl1.TabIndex = 3;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.panel6);
            this.tabPage1.Controls.Add(this.panel1);
            this.tabPage1.Controls.Add(this.pictureBox1);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.textBox_searchAutopark);
            this.tabPage1.Controls.Add(this.button6);
            this.tabPage1.Controls.Add(this.dataGridView1);
            this.tabPage1.Location = new System.Drawing.Point(4, 29);
            this.tabPage1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage1.Size = new System.Drawing.Size(1222, 569);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Автопарк";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.Gainsboro;
            this.panel6.Controls.Add(this.button1_change);
            this.panel6.Controls.Add(this.label39);
            this.panel6.Controls.Add(this.button1_save);
            this.panel6.Controls.Add(this.button1_delete);
            this.panel6.Location = new System.Drawing.Point(759, 204);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(301, 307);
            this.panel6.TabIndex = 11;
            // 
            // button1_change
            // 
            this.button1_change.BackColor = System.Drawing.Color.PaleTurquoise;
            this.button1_change.Location = new System.Drawing.Point(103, 82);
            this.button1_change.Name = "button1_change";
            this.button1_change.Size = new System.Drawing.Size(103, 44);
            this.button1_change.TabIndex = 11;
            this.button1_change.Text = "Изменить";
            this.button1_change.UseVisualStyleBackColor = false;
            this.button1_change.Click += new System.EventHandler(this.button1_change_Click);
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label39.Location = new System.Drawing.Point(57, 14);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(200, 28);
            this.label39.TabIndex = 10;
            this.label39.Text = "Изменение таблицы";
            // 
            // button1_save
            // 
            this.button1_save.BackColor = System.Drawing.Color.PaleGreen;
            this.button1_save.Location = new System.Drawing.Point(103, 215);
            this.button1_save.Name = "button1_save";
            this.button1_save.Size = new System.Drawing.Size(103, 44);
            this.button1_save.TabIndex = 9;
            this.button1_save.Text = "Сохранить";
            this.button1_save.UseVisualStyleBackColor = false;
            this.button1_save.Click += new System.EventHandler(this.button1_save_Click);
            // 
            // button1_delete
            // 
            this.button1_delete.BackColor = System.Drawing.Color.Salmon;
            this.button1_delete.Location = new System.Drawing.Point(103, 147);
            this.button1_delete.Name = "button1_delete";
            this.button1_delete.Size = new System.Drawing.Size(103, 44);
            this.button1_delete.TabIndex = 8;
            this.button1_delete.Text = "Удалить";
            this.button1_delete.UseVisualStyleBackColor = false;
            this.button1_delete.Click += new System.EventHandler(this.button1_delete_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = global::WinFormsApp1.Properties.Resources.search;
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Location = new System.Drawing.Point(682, 46);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(36, 36);
            this.pictureBox1.TabIndex = 7;
            this.pictureBox1.TabStop = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(718, 52);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(208, 20);
            this.label2.TabIndex = 6;
            this.label2.Text = "Поиск по таблице Автопарк:";
            // 
            // textBox_searchAutopark
            // 
            this.textBox_searchAutopark.Location = new System.Drawing.Point(682, 88);
            this.textBox_searchAutopark.Name = "textBox_searchAutopark";
            this.textBox_searchAutopark.Size = new System.Drawing.Size(283, 27);
            this.textBox_searchAutopark.TabIndex = 5;
            this.textBox_searchAutopark.TextChanged += new System.EventHandler(this.textBox_searchAutopark_TextChanged);
            // 
            // button6
            // 
            this.button6.BackgroundImage = global::WinFormsApp1.Properties.Resources._61444;
            this.button6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button6.Location = new System.Drawing.Point(514, 369);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(47, 47);
            this.button6.TabIndex = 4;
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.panel7);
            this.tabPage2.Controls.Add(this.button1);
            this.tabPage2.Controls.Add(this.pictureBox2);
            this.tabPage2.Controls.Add(this.label14);
            this.tabPage2.Controls.Add(this.textBox_searchCar);
            this.tabPage2.Controls.Add(this.panel2);
            this.tabPage2.Controls.Add(this.dataGridView2);
            this.tabPage2.Location = new System.Drawing.Point(4, 29);
            this.tabPage2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage2.Size = new System.Drawing.Size(1222, 569);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Автомобиль";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.Gainsboro;
            this.panel7.Controls.Add(this.button2_change);
            this.panel7.Controls.Add(this.label40);
            this.panel7.Controls.Add(this.button2_save);
            this.panel7.Controls.Add(this.button2_delete);
            this.panel7.Location = new System.Drawing.Point(939, 253);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(264, 266);
            this.panel7.TabIndex = 12;
            // 
            // button2_change
            // 
            this.button2_change.BackColor = System.Drawing.Color.PaleTurquoise;
            this.button2_change.Location = new System.Drawing.Point(80, 63);
            this.button2_change.Name = "button2_change";
            this.button2_change.Size = new System.Drawing.Size(103, 44);
            this.button2_change.TabIndex = 12;
            this.button2_change.Text = "Изменить";
            this.button2_change.UseVisualStyleBackColor = false;
            this.button2_change.Click += new System.EventHandler(this.button2_change_Click);
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label40.Location = new System.Drawing.Point(35, 12);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(200, 28);
            this.label40.TabIndex = 10;
            this.label40.Text = "Изменение таблицы";
            // 
            // button2_save
            // 
            this.button2_save.BackColor = System.Drawing.Color.PaleGreen;
            this.button2_save.Location = new System.Drawing.Point(80, 213);
            this.button2_save.Name = "button2_save";
            this.button2_save.Size = new System.Drawing.Size(103, 44);
            this.button2_save.TabIndex = 9;
            this.button2_save.Text = "Сохранить";
            this.button2_save.UseVisualStyleBackColor = false;
            this.button2_save.Click += new System.EventHandler(this.button2_save_Click);
            // 
            // button2_delete
            // 
            this.button2_delete.BackColor = System.Drawing.Color.Salmon;
            this.button2_delete.Location = new System.Drawing.Point(80, 136);
            this.button2_delete.Name = "button2_delete";
            this.button2_delete.Size = new System.Drawing.Size(103, 44);
            this.button2_delete.TabIndex = 8;
            this.button2_delete.Text = "Удалить";
            this.button2_delete.UseVisualStyleBackColor = false;
            this.button2_delete.Click += new System.EventHandler(this.button2_delete_Click);
            // 
            // button1
            // 
            this.button1.BackgroundImage = global::WinFormsApp1.Properties.Resources._61444;
            this.button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button1.Location = new System.Drawing.Point(868, 382);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(47, 47);
            this.button1.TabIndex = 11;
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackgroundImage = global::WinFormsApp1.Properties.Resources.search;
            this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox2.Location = new System.Drawing.Point(933, 46);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(35, 36);
            this.pictureBox2.TabIndex = 10;
            this.pictureBox2.TabStop = false;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(974, 46);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(229, 20);
            this.label14.TabIndex = 9;
            this.label14.Text = "Поиск по таблице Автомобиль:";
            // 
            // textBox_searchCar
            // 
            this.textBox_searchCar.Location = new System.Drawing.Point(964, 88);
            this.textBox_searchCar.Name = "textBox_searchCar";
            this.textBox_searchCar.Size = new System.Drawing.Size(239, 27);
            this.textBox_searchCar.TabIndex = 8;
            this.textBox_searchCar.TextChanged += new System.EventHandler(this.textBox_searchCar_TextChanged);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel2.Controls.Add(this.textBox_autoparkid);
            this.panel2.Controls.Add(this.label44);
            this.panel2.Controls.Add(this.button_Car);
            this.panel2.Controls.Add(this.label21);
            this.panel2.Controls.Add(this.textBox_incost);
            this.panel2.Controls.Add(this.label20);
            this.panel2.Controls.Add(this.textBox_class);
            this.panel2.Controls.Add(this.label19);
            this.panel2.Controls.Add(this.textBox_year);
            this.panel2.Controls.Add(this.label16);
            this.panel2.Controls.Add(this.label17);
            this.panel2.Controls.Add(this.label18);
            this.panel2.Controls.Add(this.textBox_rental);
            this.panel2.Controls.Add(this.textBox_status);
            this.panel2.Controls.Add(this.textBox_mileage);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Controls.Add(this.label6);
            this.panel2.Controls.Add(this.textBox_color);
            this.panel2.Controls.Add(this.textBox_model);
            this.panel2.Controls.Add(this.textBox_statenum);
            this.panel2.Location = new System.Drawing.Point(17, 288);
            this.panel2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(836, 277);
            this.panel2.TabIndex = 3;
            // 
            // textBox_autoparkid
            // 
            this.textBox_autoparkid.Location = new System.Drawing.Point(585, 204);
            this.textBox_autoparkid.Name = "textBox_autoparkid";
            this.textBox_autoparkid.Size = new System.Drawing.Size(228, 27);
            this.textBox_autoparkid.TabIndex = 20;
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Location = new System.Drawing.Point(463, 202);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(98, 20);
            this.label44.TabIndex = 19;
            this.label44.Text = "id автопарка";
            // 
            // button_Car
            // 
            this.button_Car.Location = new System.Drawing.Point(356, 245);
            this.button_Car.Name = "button_Car";
            this.button_Car.Size = new System.Drawing.Size(118, 29);
            this.button_Car.TabIndex = 18;
            this.button_Car.Text = "Заполнить";
            this.button_Car.UseVisualStyleBackColor = true;
            this.button_Car.Click += new System.EventHandler(this.button_Car_Click);
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(422, 162);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(157, 20);
            this.label21.TabIndex = 17;
            this.label21.Text = "Страховая стоимость";
            // 
            // textBox_incost
            // 
            this.textBox_incost.Location = new System.Drawing.Point(585, 159);
            this.textBox_incost.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox_incost.Name = "textBox_incost";
            this.textBox_incost.Size = new System.Drawing.Size(228, 27);
            this.textBox_incost.TabIndex = 16;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(38, 202);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(48, 20);
            this.label20.TabIndex = 15;
            this.label20.Text = "Класс";
            // 
            // textBox_class
            // 
            this.textBox_class.Location = new System.Drawing.Point(160, 200);
            this.textBox_class.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox_class.Name = "textBox_class";
            this.textBox_class.Size = new System.Drawing.Size(228, 27);
            this.textBox_class.TabIndex = 14;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(38, 159);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(94, 20);
            this.label19.TabIndex = 13;
            this.label19.Text = "Год выпуска";
            // 
            // textBox_year
            // 
            this.textBox_year.Location = new System.Drawing.Point(160, 156);
            this.textBox_year.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox_year.Name = "textBox_year";
            this.textBox_year.Size = new System.Drawing.Size(228, 27);
            this.textBox_year.TabIndex = 12;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(463, 112);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(105, 20);
            this.label16.TabIndex = 11;
            this.label16.Text = "Цена проката";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(463, 68);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(52, 20);
            this.label17.TabIndex = 10;
            this.label17.Text = "Статус";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(463, 28);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(61, 20);
            this.label18.TabIndex = 9;
            this.label18.Text = "Пробег";
            // 
            // textBox_rental
            // 
            this.textBox_rental.Location = new System.Drawing.Point(585, 110);
            this.textBox_rental.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox_rental.Name = "textBox_rental";
            this.textBox_rental.Size = new System.Drawing.Size(228, 27);
            this.textBox_rental.TabIndex = 8;
            // 
            // textBox_status
            // 
            this.textBox_status.Location = new System.Drawing.Point(585, 65);
            this.textBox_status.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox_status.Name = "textBox_status";
            this.textBox_status.Size = new System.Drawing.Size(228, 27);
            this.textBox_status.TabIndex = 7;
            // 
            // textBox_mileage
            // 
            this.textBox_mileage.Location = new System.Drawing.Point(585, 22);
            this.textBox_mileage.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox_mileage.Name = "textBox_mileage";
            this.textBox_mileage.Size = new System.Drawing.Size(228, 27);
            this.textBox_mileage.TabIndex = 6;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(38, 112);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(42, 20);
            this.label1.TabIndex = 5;
            this.label1.Text = "Цвет";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(27, 68);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(63, 20);
            this.label5.TabIndex = 4;
            this.label5.Text = "Модель";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label6.ForeColor = System.Drawing.Color.Red;
            this.label6.Location = new System.Drawing.Point(18, 22);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(81, 20);
            this.label6.TabIndex = 3;
            this.label6.Text = "Гос.номер";
            // 
            // textBox_color
            // 
            this.textBox_color.Location = new System.Drawing.Point(160, 110);
            this.textBox_color.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox_color.Name = "textBox_color";
            this.textBox_color.Size = new System.Drawing.Size(228, 27);
            this.textBox_color.TabIndex = 2;
            // 
            // textBox_model
            // 
            this.textBox_model.Location = new System.Drawing.Point(160, 65);
            this.textBox_model.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox_model.Name = "textBox_model";
            this.textBox_model.Size = new System.Drawing.Size(228, 27);
            this.textBox_model.TabIndex = 1;
            // 
            // textBox_statenum
            // 
            this.textBox_statenum.Location = new System.Drawing.Point(160, 22);
            this.textBox_statenum.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox_statenum.Name = "textBox_statenum";
            this.textBox_statenum.Size = new System.Drawing.Size(228, 27);
            this.textBox_statenum.TabIndex = 0;
            // 
            // dataGridView2
            // 
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Location = new System.Drawing.Point(-4, 0);
            this.dataGridView2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.RowHeadersWidth = 51;
            this.dataGridView2.RowTemplate.Height = 29;
            this.dataGridView2.Size = new System.Drawing.Size(919, 269);
            this.dataGridView2.TabIndex = 1;
            this.dataGridView2.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView2_CellClick);
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.panel8);
            this.tabPage3.Controls.Add(this.button7);
            this.tabPage3.Controls.Add(this.pictureBox3);
            this.tabPage3.Controls.Add(this.label15);
            this.tabPage3.Controls.Add(this.textBox_searchClient);
            this.tabPage3.Controls.Add(this.panel3);
            this.tabPage3.Controls.Add(this.dataGridView3);
            this.tabPage3.Location = new System.Drawing.Point(4, 29);
            this.tabPage3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage3.Size = new System.Drawing.Size(1222, 569);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Клиент";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.Gainsboro;
            this.panel8.Controls.Add(this.button3_change);
            this.panel8.Controls.Add(this.label41);
            this.panel8.Controls.Add(this.button3_save);
            this.panel8.Controls.Add(this.button3_delete);
            this.panel8.Location = new System.Drawing.Point(955, 190);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(248, 336);
            this.panel8.TabIndex = 15;
            // 
            // button3_change
            // 
            this.button3_change.BackColor = System.Drawing.Color.PaleTurquoise;
            this.button3_change.Location = new System.Drawing.Point(75, 93);
            this.button3_change.Name = "button3_change";
            this.button3_change.Size = new System.Drawing.Size(103, 44);
            this.button3_change.TabIndex = 12;
            this.button3_change.Text = "Изменить";
            this.button3_change.UseVisualStyleBackColor = false;
            this.button3_change.Click += new System.EventHandler(this.button3_change_Click);
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label41.Location = new System.Drawing.Point(20, 11);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(200, 28);
            this.label41.TabIndex = 10;
            this.label41.Text = "Изменение таблицы";
            // 
            // button3_save
            // 
            this.button3_save.BackColor = System.Drawing.Color.PaleGreen;
            this.button3_save.Location = new System.Drawing.Point(75, 251);
            this.button3_save.Name = "button3_save";
            this.button3_save.Size = new System.Drawing.Size(103, 44);
            this.button3_save.TabIndex = 9;
            this.button3_save.Text = "Сохранить";
            this.button3_save.UseVisualStyleBackColor = false;
            this.button3_save.Click += new System.EventHandler(this.button3_save_Click);
            // 
            // button3_delete
            // 
            this.button3_delete.BackColor = System.Drawing.Color.Salmon;
            this.button3_delete.Location = new System.Drawing.Point(75, 172);
            this.button3_delete.Name = "button3_delete";
            this.button3_delete.Size = new System.Drawing.Size(103, 44);
            this.button3_delete.TabIndex = 8;
            this.button3_delete.Text = "Удалить";
            this.button3_delete.UseVisualStyleBackColor = false;
            this.button3_delete.Click += new System.EventHandler(this.button3_delete_Click);
            // 
            // button7
            // 
            this.button7.BackgroundImage = global::WinFormsApp1.Properties.Resources._61444;
            this.button7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button7.Location = new System.Drawing.Point(882, 380);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(47, 47);
            this.button7.TabIndex = 14;
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackgroundImage = global::WinFormsApp1.Properties.Resources.search;
            this.pictureBox3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox3.Location = new System.Drawing.Point(943, 43);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(35, 36);
            this.pictureBox3.TabIndex = 13;
            this.pictureBox3.TabStop = false;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(999, 43);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(191, 20);
            this.label15.TabIndex = 12;
            this.label15.Text = "Поиск по таблице Клиент:";
            // 
            // textBox_searchClient
            // 
            this.textBox_searchClient.Location = new System.Drawing.Point(951, 96);
            this.textBox_searchClient.Name = "textBox_searchClient";
            this.textBox_searchClient.Size = new System.Drawing.Size(239, 27);
            this.textBox_searchClient.TabIndex = 11;
            this.textBox_searchClient.TextChanged += new System.EventHandler(this.textBox_searchClient_TextChanged);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel3.Controls.Add(this.button_Client);
            this.panel3.Controls.Add(this.label25);
            this.panel3.Controls.Add(this.textBox_numcar);
            this.panel3.Controls.Add(this.label26);
            this.panel3.Controls.Add(this.textBox_patclient);
            this.panel3.Controls.Add(this.label22);
            this.panel3.Controls.Add(this.label23);
            this.panel3.Controls.Add(this.label24);
            this.panel3.Controls.Add(this.textBox_phoneclient);
            this.panel3.Controls.Add(this.textBox_addressclient);
            this.panel3.Controls.Add(this.textBox_passport);
            this.panel3.Controls.Add(this.label7);
            this.panel3.Controls.Add(this.label8);
            this.panel3.Controls.Add(this.label9);
            this.panel3.Controls.Add(this.textBox_surclient);
            this.panel3.Controls.Add(this.textBox_nameclient);
            this.panel3.Controls.Add(this.textBox_idclient);
            this.panel3.Location = new System.Drawing.Point(18, 292);
            this.panel3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(858, 248);
            this.panel3.TabIndex = 3;
            // 
            // button_Client
            // 
            this.button_Client.Location = new System.Drawing.Point(396, 205);
            this.button_Client.Name = "button_Client";
            this.button_Client.Size = new System.Drawing.Size(118, 29);
            this.button_Client.TabIndex = 16;
            this.button_Client.Text = "Заполнить";
            this.button_Client.UseVisualStyleBackColor = true;
            this.button_Client.Click += new System.EventHandler(this.button_Client_Click);
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(415, 158);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(146, 20);
            this.label25.TabIndex = 15;
            this.label25.Text = "Номер автомобиля";
            // 
            // textBox_numcar
            // 
            this.textBox_numcar.Location = new System.Drawing.Point(567, 158);
            this.textBox_numcar.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox_numcar.Name = "textBox_numcar";
            this.textBox_numcar.Size = new System.Drawing.Size(228, 27);
            this.textBox_numcar.TabIndex = 14;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(38, 156);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(72, 20);
            this.label26.TabIndex = 13;
            this.label26.Text = "Отчество";
            // 
            // textBox_patclient
            // 
            this.textBox_patclient.Location = new System.Drawing.Point(160, 156);
            this.textBox_patclient.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox_patclient.Name = "textBox_patclient";
            this.textBox_patclient.Size = new System.Drawing.Size(228, 27);
            this.textBox_patclient.TabIndex = 12;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(445, 115);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(69, 20);
            this.label22.TabIndex = 11;
            this.label22.Text = "Телефон";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(445, 70);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(55, 20);
            this.label23.TabIndex = 10;
            this.label23.Text = "Адрес ";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(445, 29);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(68, 20);
            this.label24.TabIndex = 9;
            this.label24.Text = "Паспорт";
            // 
            // textBox_phoneclient
            // 
            this.textBox_phoneclient.Location = new System.Drawing.Point(567, 112);
            this.textBox_phoneclient.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox_phoneclient.Name = "textBox_phoneclient";
            this.textBox_phoneclient.Size = new System.Drawing.Size(228, 27);
            this.textBox_phoneclient.TabIndex = 8;
            // 
            // textBox_addressclient
            // 
            this.textBox_addressclient.Location = new System.Drawing.Point(567, 68);
            this.textBox_addressclient.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox_addressclient.Name = "textBox_addressclient";
            this.textBox_addressclient.Size = new System.Drawing.Size(228, 27);
            this.textBox_addressclient.TabIndex = 7;
            // 
            // textBox_passport
            // 
            this.textBox_passport.Location = new System.Drawing.Point(567, 24);
            this.textBox_passport.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox_passport.Name = "textBox_passport";
            this.textBox_passport.Size = new System.Drawing.Size(228, 27);
            this.textBox_passport.TabIndex = 6;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(38, 112);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(73, 20);
            this.label7.TabIndex = 5;
            this.label7.Text = "Фамилия";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(38, 70);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(39, 20);
            this.label8.TabIndex = 4;
            this.label8.Text = "Имя";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.ForeColor = System.Drawing.Color.Red;
            this.label9.Location = new System.Drawing.Point(38, 28);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(24, 20);
            this.label9.TabIndex = 3;
            this.label9.Text = "ID";
            // 
            // textBox_surclient
            // 
            this.textBox_surclient.Location = new System.Drawing.Point(160, 110);
            this.textBox_surclient.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox_surclient.Name = "textBox_surclient";
            this.textBox_surclient.Size = new System.Drawing.Size(228, 27);
            this.textBox_surclient.TabIndex = 2;
            // 
            // textBox_nameclient
            // 
            this.textBox_nameclient.Location = new System.Drawing.Point(160, 65);
            this.textBox_nameclient.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox_nameclient.Name = "textBox_nameclient";
            this.textBox_nameclient.Size = new System.Drawing.Size(228, 27);
            this.textBox_nameclient.TabIndex = 1;
            // 
            // textBox_idclient
            // 
            this.textBox_idclient.Location = new System.Drawing.Point(160, 22);
            this.textBox_idclient.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox_idclient.Name = "textBox_idclient";
            this.textBox_idclient.Size = new System.Drawing.Size(228, 27);
            this.textBox_idclient.TabIndex = 0;
            // 
            // dataGridView3
            // 
            this.dataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView3.Location = new System.Drawing.Point(6, 6);
            this.dataGridView3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dataGridView3.Name = "dataGridView3";
            this.dataGridView3.RowHeadersWidth = 51;
            this.dataGridView3.RowTemplate.Height = 29;
            this.dataGridView3.Size = new System.Drawing.Size(889, 259);
            this.dataGridView3.TabIndex = 1;
            this.dataGridView3.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView3_CellClick);
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.panel9);
            this.tabPage4.Controls.Add(this.button8);
            this.tabPage4.Controls.Add(this.pictureBox4);
            this.tabPage4.Controls.Add(this.label30);
            this.tabPage4.Controls.Add(this.textBox_searchRental);
            this.tabPage4.Controls.Add(this.panel4);
            this.tabPage4.Controls.Add(this.dataGridView4);
            this.tabPage4.Location = new System.Drawing.Point(4, 29);
            this.tabPage4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage4.Size = new System.Drawing.Size(1222, 569);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Прокат";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.Color.Gainsboro;
            this.panel9.Controls.Add(this.button4_change);
            this.panel9.Controls.Add(this.label42);
            this.panel9.Controls.Add(this.button4_save);
            this.panel9.Controls.Add(this.button4_delete);
            this.panel9.Location = new System.Drawing.Point(966, 218);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(236, 300);
            this.panel9.TabIndex = 15;
            // 
            // button4_change
            // 
            this.button4_change.BackColor = System.Drawing.Color.PaleTurquoise;
            this.button4_change.Location = new System.Drawing.Point(72, 83);
            this.button4_change.Name = "button4_change";
            this.button4_change.Size = new System.Drawing.Size(103, 44);
            this.button4_change.TabIndex = 12;
            this.button4_change.Text = "Изменить";
            this.button4_change.UseVisualStyleBackColor = false;
            this.button4_change.Click += new System.EventHandler(this.button4_change_Click);
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label42.Location = new System.Drawing.Point(20, 19);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(200, 28);
            this.label42.TabIndex = 10;
            this.label42.Text = "Изменение таблицы";
            // 
            // button4_save
            // 
            this.button4_save.BackColor = System.Drawing.Color.PaleGreen;
            this.button4_save.Location = new System.Drawing.Point(72, 225);
            this.button4_save.Name = "button4_save";
            this.button4_save.Size = new System.Drawing.Size(103, 44);
            this.button4_save.TabIndex = 9;
            this.button4_save.Text = "Сохранить";
            this.button4_save.UseVisualStyleBackColor = false;
            this.button4_save.Click += new System.EventHandler(this.button4_save_Click);
            // 
            // button4_delete
            // 
            this.button4_delete.BackColor = System.Drawing.Color.Salmon;
            this.button4_delete.Location = new System.Drawing.Point(72, 157);
            this.button4_delete.Name = "button4_delete";
            this.button4_delete.Size = new System.Drawing.Size(103, 44);
            this.button4_delete.TabIndex = 8;
            this.button4_delete.Text = "Удалить";
            this.button4_delete.UseVisualStyleBackColor = false;
            this.button4_delete.Click += new System.EventHandler(this.button4_delete_Click);
            // 
            // button8
            // 
            this.button8.BackgroundImage = global::WinFormsApp1.Properties.Resources._61444;
            this.button8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button8.Location = new System.Drawing.Point(901, 375);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(47, 47);
            this.button8.TabIndex = 14;
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // pictureBox4
            // 
            this.pictureBox4.BackgroundImage = global::WinFormsApp1.Properties.Resources.search;
            this.pictureBox4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox4.Location = new System.Drawing.Point(943, 48);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(35, 36);
            this.pictureBox4.TabIndex = 13;
            this.pictureBox4.TabStop = false;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(1004, 48);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(192, 20);
            this.label30.TabIndex = 12;
            this.label30.Text = "Поиск по таблице Прокат:";
            // 
            // textBox_searchRental
            // 
            this.textBox_searchRental.Location = new System.Drawing.Point(957, 107);
            this.textBox_searchRental.Name = "textBox_searchRental";
            this.textBox_searchRental.Size = new System.Drawing.Size(239, 27);
            this.textBox_searchRental.TabIndex = 11;
            this.textBox_searchRental.TextChanged += new System.EventHandler(this.textBox_searchRental_TextChanged);
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel4.Controls.Add(this.button_Rental);
            this.panel4.Controls.Add(this.label27);
            this.panel4.Controls.Add(this.label28);
            this.panel4.Controls.Add(this.label29);
            this.panel4.Controls.Add(this.textBox_workerid);
            this.panel4.Controls.Add(this.textBox_carid);
            this.panel4.Controls.Add(this.textBox_clientid);
            this.panel4.Controls.Add(this.label10);
            this.panel4.Controls.Add(this.label11);
            this.panel4.Controls.Add(this.label12);
            this.panel4.Controls.Add(this.textBox_days);
            this.panel4.Controls.Add(this.textBox_date);
            this.panel4.Controls.Add(this.textBox_request);
            this.panel4.Location = new System.Drawing.Point(34, 290);
            this.panel4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(840, 204);
            this.panel4.TabIndex = 3;
            // 
            // button_Rental
            // 
            this.button_Rental.Location = new System.Drawing.Point(362, 161);
            this.button_Rental.Name = "button_Rental";
            this.button_Rental.Size = new System.Drawing.Size(118, 29);
            this.button_Rental.TabIndex = 12;
            this.button_Rental.Text = "Заполнить";
            this.button_Rental.UseVisualStyleBackColor = true;
            this.button_Rental.Click += new System.EventHandler(this.button_Rental_Click);
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(421, 112);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(102, 20);
            this.label27.TabIndex = 11;
            this.label27.Text = "ID работника";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(420, 68);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(146, 20);
            this.label28.TabIndex = 10;
            this.label28.Text = "Номер автомобиля";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(421, 28);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(83, 20);
            this.label29.TabIndex = 9;
            this.label29.Text = "ID клиента";
            // 
            // textBox_workerid
            // 
            this.textBox_workerid.Location = new System.Drawing.Point(572, 106);
            this.textBox_workerid.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox_workerid.Name = "textBox_workerid";
            this.textBox_workerid.Size = new System.Drawing.Size(228, 27);
            this.textBox_workerid.TabIndex = 8;
            // 
            // textBox_carid
            // 
            this.textBox_carid.Location = new System.Drawing.Point(572, 61);
            this.textBox_carid.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox_carid.Name = "textBox_carid";
            this.textBox_carid.Size = new System.Drawing.Size(228, 27);
            this.textBox_carid.TabIndex = 7;
            // 
            // textBox_clientid
            // 
            this.textBox_clientid.Location = new System.Drawing.Point(572, 22);
            this.textBox_clientid.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox_clientid.Name = "textBox_clientid";
            this.textBox_clientid.Size = new System.Drawing.Size(228, 27);
            this.textBox_clientid.TabIndex = 6;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(14, 112);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(156, 20);
            this.label10.TabIndex = 5;
            this.label10.Text = "Кол-во дней проката";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(14, 68);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(101, 20);
            this.label11.TabIndex = 4;
            this.label11.Text = "Дата проката";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.ForeColor = System.Drawing.Color.Red;
            this.label12.Location = new System.Drawing.Point(24, 28);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(108, 20);
            this.label12.TabIndex = 3;
            this.label12.Text = "Номер заявки";
            // 
            // textBox_days
            // 
            this.textBox_days.Location = new System.Drawing.Point(176, 110);
            this.textBox_days.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox_days.Name = "textBox_days";
            this.textBox_days.Size = new System.Drawing.Size(228, 27);
            this.textBox_days.TabIndex = 2;
            // 
            // textBox_date
            // 
            this.textBox_date.Location = new System.Drawing.Point(176, 65);
            this.textBox_date.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox_date.Name = "textBox_date";
            this.textBox_date.Size = new System.Drawing.Size(228, 27);
            this.textBox_date.TabIndex = 1;
            // 
            // textBox_request
            // 
            this.textBox_request.Location = new System.Drawing.Point(176, 20);
            this.textBox_request.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox_request.Name = "textBox_request";
            this.textBox_request.Size = new System.Drawing.Size(228, 27);
            this.textBox_request.TabIndex = 0;
            // 
            // dataGridView4
            // 
            this.dataGridView4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView4.Location = new System.Drawing.Point(6, 6);
            this.dataGridView4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dataGridView4.Name = "dataGridView4";
            this.dataGridView4.RowHeadersWidth = 51;
            this.dataGridView4.RowTemplate.Height = 29;
            this.dataGridView4.Size = new System.Drawing.Size(912, 259);
            this.dataGridView4.TabIndex = 1;
            this.dataGridView4.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView4_CellClick);
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.panel10);
            this.tabPage5.Controls.Add(this.button9);
            this.tabPage5.Controls.Add(this.pictureBox5);
            this.tabPage5.Controls.Add(this.label38);
            this.tabPage5.Controls.Add(this.textBox_searchWorker);
            this.tabPage5.Controls.Add(this.panel5);
            this.tabPage5.Controls.Add(this.dataGridView5);
            this.tabPage5.Location = new System.Drawing.Point(4, 29);
            this.tabPage5.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage5.Size = new System.Drawing.Size(1222, 569);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "Работник";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // panel10
            // 
            this.panel10.BackColor = System.Drawing.Color.Gainsboro;
            this.panel10.Controls.Add(this.button5_change);
            this.panel10.Controls.Add(this.label43);
            this.panel10.Controls.Add(this.button5_save);
            this.panel10.Controls.Add(this.button5_delete);
            this.panel10.Location = new System.Drawing.Point(979, 214);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(230, 295);
            this.panel10.TabIndex = 15;
            // 
            // button5_change
            // 
            this.button5_change.BackColor = System.Drawing.Color.PaleTurquoise;
            this.button5_change.Location = new System.Drawing.Point(70, 71);
            this.button5_change.Name = "button5_change";
            this.button5_change.Size = new System.Drawing.Size(103, 44);
            this.button5_change.TabIndex = 12;
            this.button5_change.Text = "Изменить";
            this.button5_change.UseVisualStyleBackColor = false;
            this.button5_change.Click += new System.EventHandler(this.button5_change_Click);
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label43.Location = new System.Drawing.Point(18, 12);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(200, 28);
            this.label43.TabIndex = 10;
            this.label43.Text = "Изменение таблицы";
            // 
            // button5_save
            // 
            this.button5_save.BackColor = System.Drawing.Color.PaleGreen;
            this.button5_save.Location = new System.Drawing.Point(70, 223);
            this.button5_save.Name = "button5_save";
            this.button5_save.Size = new System.Drawing.Size(103, 44);
            this.button5_save.TabIndex = 9;
            this.button5_save.Text = "Сохранить";
            this.button5_save.UseVisualStyleBackColor = false;
            this.button5_save.Click += new System.EventHandler(this.button5_save_Click);
            // 
            // button5_delete
            // 
            this.button5_delete.BackColor = System.Drawing.Color.Salmon;
            this.button5_delete.Location = new System.Drawing.Point(70, 146);
            this.button5_delete.Name = "button5_delete";
            this.button5_delete.Size = new System.Drawing.Size(103, 44);
            this.button5_delete.TabIndex = 8;
            this.button5_delete.Text = "Удалить";
            this.button5_delete.UseVisualStyleBackColor = false;
            this.button5_delete.Click += new System.EventHandler(this.button5_delete_Click);
            // 
            // button9
            // 
            this.button9.BackgroundImage = global::WinFormsApp1.Properties.Resources._61444;
            this.button9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button9.Location = new System.Drawing.Point(926, 379);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(47, 47);
            this.button9.TabIndex = 14;
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // pictureBox5
            // 
            this.pictureBox5.BackgroundImage = global::WinFormsApp1.Properties.Resources.search;
            this.pictureBox5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox5.Location = new System.Drawing.Point(962, 37);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(35, 36);
            this.pictureBox5.TabIndex = 13;
            this.pictureBox5.TabStop = false;
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(1002, 37);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(207, 20);
            this.label38.TabIndex = 12;
            this.label38.Text = "Поиск по таблице Работник:";
            // 
            // textBox_searchWorker
            // 
            this.textBox_searchWorker.Location = new System.Drawing.Point(970, 88);
            this.textBox_searchWorker.Name = "textBox_searchWorker";
            this.textBox_searchWorker.Size = new System.Drawing.Size(239, 27);
            this.textBox_searchWorker.TabIndex = 11;
            this.textBox_searchWorker.TextChanged += new System.EventHandler(this.textBox_searchWorker_TextChanged);
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel5.Controls.Add(this.button_Worker);
            this.panel5.Controls.Add(this.label31);
            this.panel5.Controls.Add(this.textBox_patworker);
            this.panel5.Controls.Add(this.label32);
            this.panel5.Controls.Add(this.label33);
            this.panel5.Controls.Add(this.label34);
            this.panel5.Controls.Add(this.textBox_opermode);
            this.panel5.Controls.Add(this.textBox_phoneworker);
            this.panel5.Controls.Add(this.textBox_position);
            this.panel5.Controls.Add(this.label35);
            this.panel5.Controls.Add(this.label36);
            this.panel5.Controls.Add(this.label37);
            this.panel5.Controls.Add(this.textBox_surworker);
            this.panel5.Controls.Add(this.textBox_nameworker);
            this.panel5.Controls.Add(this.textBox_idworker);
            this.panel5.Location = new System.Drawing.Point(17, 294);
            this.panel5.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(893, 204);
            this.panel5.TabIndex = 3;
            // 
            // button_Worker
            // 
            this.button_Worker.Location = new System.Drawing.Point(666, 155);
            this.button_Worker.Name = "button_Worker";
            this.button_Worker.Size = new System.Drawing.Size(118, 29);
            this.button_Worker.TabIndex = 30;
            this.button_Worker.Text = "Заполнить";
            this.button_Worker.UseVisualStyleBackColor = true;
            this.button_Worker.Click += new System.EventHandler(this.button_Worker_Click);
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(83, 155);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(72, 20);
            this.label31.TabIndex = 29;
            this.label31.Text = "Отчество";
            // 
            // textBox_patworker
            // 
            this.textBox_patworker.Location = new System.Drawing.Point(205, 155);
            this.textBox_patworker.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox_patworker.Name = "textBox_patworker";
            this.textBox_patworker.Size = new System.Drawing.Size(228, 27);
            this.textBox_patworker.TabIndex = 28;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(490, 114);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(112, 20);
            this.label32.TabIndex = 27;
            this.label32.Text = "Режим работы";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(490, 69);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(69, 20);
            this.label33.TabIndex = 26;
            this.label33.Text = "Телефон";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(490, 28);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(86, 20);
            this.label34.TabIndex = 25;
            this.label34.Text = "Должность";
            // 
            // textBox_opermode
            // 
            this.textBox_opermode.Location = new System.Drawing.Point(612, 111);
            this.textBox_opermode.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox_opermode.Name = "textBox_opermode";
            this.textBox_opermode.Size = new System.Drawing.Size(228, 27);
            this.textBox_opermode.TabIndex = 24;
            // 
            // textBox_phoneworker
            // 
            this.textBox_phoneworker.Location = new System.Drawing.Point(612, 66);
            this.textBox_phoneworker.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox_phoneworker.Name = "textBox_phoneworker";
            this.textBox_phoneworker.Size = new System.Drawing.Size(228, 27);
            this.textBox_phoneworker.TabIndex = 23;
            // 
            // textBox_position
            // 
            this.textBox_position.Location = new System.Drawing.Point(612, 22);
            this.textBox_position.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox_position.Name = "textBox_position";
            this.textBox_position.Size = new System.Drawing.Size(228, 27);
            this.textBox_position.TabIndex = 22;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(83, 112);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(73, 20);
            this.label35.TabIndex = 21;
            this.label35.Text = "Фамилия";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(83, 69);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(39, 20);
            this.label36.TabIndex = 20;
            this.label36.Text = "Имя";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.ForeColor = System.Drawing.Color.Red;
            this.label37.Location = new System.Drawing.Point(83, 26);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(24, 20);
            this.label37.TabIndex = 19;
            this.label37.Text = "ID";
            // 
            // textBox_surworker
            // 
            this.textBox_surworker.Location = new System.Drawing.Point(205, 109);
            this.textBox_surworker.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox_surworker.Name = "textBox_surworker";
            this.textBox_surworker.Size = new System.Drawing.Size(228, 27);
            this.textBox_surworker.TabIndex = 18;
            // 
            // textBox_nameworker
            // 
            this.textBox_nameworker.Location = new System.Drawing.Point(205, 64);
            this.textBox_nameworker.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox_nameworker.Name = "textBox_nameworker";
            this.textBox_nameworker.Size = new System.Drawing.Size(228, 27);
            this.textBox_nameworker.TabIndex = 17;
            // 
            // textBox_idworker
            // 
            this.textBox_idworker.Location = new System.Drawing.Point(205, 21);
            this.textBox_idworker.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox_idworker.Name = "textBox_idworker";
            this.textBox_idworker.Size = new System.Drawing.Size(228, 27);
            this.textBox_idworker.TabIndex = 16;
            // 
            // dataGridView5
            // 
            this.dataGridView5.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView5.Location = new System.Drawing.Point(6, 6);
            this.dataGridView5.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dataGridView5.Name = "dataGridView5";
            this.dataGridView5.RowHeadersWidth = 51;
            this.dataGridView5.RowTemplate.Height = 29;
            this.dataGridView5.Size = new System.Drawing.Size(933, 259);
            this.dataGridView5.TabIndex = 1;
            this.dataGridView5.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView5_CellClick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1248, 619);
            this.Controls.Add(this.tabControl1);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).EndInit();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).EndInit();
            this.tabPage5.ResumeLayout(false);
            this.tabPage5.PerformLayout();
            this.panel10.ResumeLayout(false);
            this.panel10.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView5)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBox_phone;
        private System.Windows.Forms.TextBox textBox_address;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textBox_color;
        private System.Windows.Forms.TextBox textBox_model;
        private System.Windows.Forms.TextBox textBox_statenum;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox textBox_surclient;
        private System.Windows.Forms.TextBox textBox_nameclient;
        private System.Windows.Forms.TextBox textBox_idclient;
        private System.Windows.Forms.DataGridView dataGridView3;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox textBox_days;
        private System.Windows.Forms.TextBox textBox_date;
        private System.Windows.Forms.TextBox textBox_request;
        private System.Windows.Forms.DataGridView dataGridView4;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.DataGridView dataGridView5;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox textBox_rental;
        private System.Windows.Forms.TextBox textBox_status;
        private System.Windows.Forms.TextBox textBox_mileage;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox textBox_incost;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox textBox_class;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox textBox_year;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.TextBox textBox_numcar;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.TextBox textBox_patclient;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.TextBox textBox_phoneclient;
        private System.Windows.Forms.TextBox textBox_addressclient;
        private System.Windows.Forms.TextBox textBox_passport;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.TextBox textBox_workerid;
        private System.Windows.Forms.TextBox textBox_carid;
        private System.Windows.Forms.TextBox textBox_clientid;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.TextBox textBox_patworker;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.TextBox textBox_opermode;
        private System.Windows.Forms.TextBox textBox_phoneworker;
        private System.Windows.Forms.TextBox textBox_position;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.TextBox textBox_surworker;
        private System.Windows.Forms.TextBox textBox_nameworker;
        private System.Windows.Forms.TextBox textBox_idworker;
        private System.Windows.Forms.Button button_Autopark;
        private System.Windows.Forms.Button button_Car;
        private System.Windows.Forms.Button button_Client;
        private System.Windows.Forms.Button button_Rental;
        private System.Windows.Forms.Button button_Worker;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.TextBox textBox_id;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox_searchAutopark;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox textBox_searchCar;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox textBox_searchClient;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.TextBox textBox_searchRental;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.TextBox textBox_searchWorker;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button1_delete;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Button button1_save;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Button button2_save;
        private System.Windows.Forms.Button button2_delete;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Button button3_save;
        private System.Windows.Forms.Button button3_delete;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Button button4_save;
        private System.Windows.Forms.Button button4_delete;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Button button5_save;
        private System.Windows.Forms.Button button5_delete;
        private System.Windows.Forms.Button button1_change;
        private System.Windows.Forms.Button button2_change;
        private System.Windows.Forms.Button button3_change;
        private System.Windows.Forms.Button button4_change;
        private System.Windows.Forms.Button button5_change;
        private System.Windows.Forms.TextBox textBox_autoparkid;
        private System.Windows.Forms.Label label44;
    }
}